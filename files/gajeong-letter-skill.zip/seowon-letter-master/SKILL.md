---
name: seowon-letter-master
description: 가정통신문에 넣을 내용(메모·항목 나열)을 주면, 연결된 폴더의 학교 가정통신문 hwpx 빈 양식을 찾아 서식은 그대로 둔 채 내용만 채워 새 한글 파일로 저장합니다. 가정통신문·학부모 안내문 작성, 학교 양식(.hwpx) 채우기 요청 시 사용하세요.
---

# 가정통신문 양식 채우기 (HWPX)

## 이 스킬이 하는 일

사용자는 **넣을 내용만** 준다. 규칙을 다시 말해 주지 않는다.
아래 절차와 규칙은 **묻지 말고 그냥 적용**한다.

1. 연결된 폴더에서 **가정통신문 빈 양식(.hwpx)** 을 찾는다.
   후보가 여럿이면 파일명에 `가정통신문` 또는 `양식` 이 든 것을 고르고, 그래도 애매하면 그때만 묻는다.
2. 양식의 **표·글꼴·여백·로고는 손대지 않고** 글자만 사용자가 준 내용으로 바꾼다.
3. **원본은 그대로 두고** 새 파일로 저장한다.
   파일명은 `가정통신문_<주제 두세 글자>.hwpx` (예: `가정통신문_상담주간.hwpx`).
4. 작업이 끝나면 **저장 위치 · 채운 항목 · 비워 둔 항목**을 한 번에 보고한다.

사용자가 준 메모가 거칠어도 된다. 항목만 나열돼 있으면 **학부모께 보내는 안내문 문체로 다듬어** 채운다.

---

## 서원고 가정통신문 양식의 자리 지도

이 양식은 표 두 개로 되어 있다.

**머리표 (2행 3열)**

| 자리 | 빈 양식의 표기 | 채우는 값 |
|---|---|---|
| 왼쪽 칸 | 학교 로고 그림 | **건드리지 않는다** |
| 가운데 위 | `가 정 통 신 문` | **건드리지 않는다** |
| 가운데 아래 | `2026학년도 [가정통신문 제목을 입력하세요]` | 학년도 + 제목 |
| 오른쪽 칸 | `○ ○ ○ 부` | 담당 부서명 (예: `교육연구부`) |

**본문 상자 (1행 1열)**

| 순서 | 빈 양식의 표기 | 채우는 값 |
|---|---|---|
| 1 | `서원고등학교 학부모님, 안녕하십니까?` | 그대로 둔다 |
| 2 | `[발신 취지를 2줄로 …]` | 인사말 겸 발신 취지 2~3줄 |
| 3~7 | `◈ [소제목 1~5 …]` 와 그 아래 회색 줄 | 항목 제목과 내용 |
| 8 | `2026년 ○○월 ○○일` | 시행일 |
| 9 | `서 원 고 등 학 교 장 (직인생략)` | **건드리지 않는다** |

`◈` 항목은 다섯 칸이 준비돼 있다. **쓰지 않는 칸은 제목 줄까지 통째로 지운다.**
내용이 다섯 개보다 많으면 성격이 가까운 것끼리 묶어 다섯 개 이내로 줄인다.

---

## 반드시 지키는 규칙

- 표 구조와 칸 수를 바꾸지 않는다. 글자만 바꾼다
- 글꼴 크기·여백·줄간격을 조정하지 않는다
- 회색 안내 글씨(`textColor="#808080"`)는 남기지 않는다. 채운 문단은 검은색 본문 charPr로 바꾼다
- 학교 로고와 학교장 줄은 그대로 둔다
- **전체가 1쪽을 넘지 않게** 한다. 넘칠 것 같으면 항목 수나 문장을 줄인다 (글꼴·여백을 줄여서 맞추지 않는다)
- **날짜, 시간, 장소, 전화번호, 금액, 인원, 담당자 이름은 지어내지 않는다.** 사용자가 주지 않았으면 `[담당자 입력]` 으로 비워 두고, 보고할 때 무엇을 비웠는지 알린다
- 학생 실명·학번·연락처를 본문에 넣지 않는다

## 문체

- 학부모를 높여 쓴다. `~하오니`, `~하여 주시기 바랍니다`, `~안내드립니다`
- 명령형은 피한다. `제출할 것` → `제출하여 주시기 바랍니다`
- 인사말은 계절 인사보다 **왜 이 안내를 보내는지**를 쓴다
- 항목 안은 개조식으로 짧게 끊는다
- 날짜는 `2026. 10. 13.(월)`, 기간은 `10. 13.(월)~10. 17.(금)`, 시간은 24시각제 `14:00~17:00`

---

# 기술 절차 — hwpx 다루기

## 1. 해제

hwpx는 XML이 든 zip이다.

```bash
mkdir -p hwpx_work && cd hwpx_work
cp 원본.hwpx 원본.zip
unzip -o 원본.zip -d original
```

- `Contents/section0.xml` — 본문. **여기만 수정한다**
- `Contents/header.xml` — 글꼴·문단 스타일·표 테두리 선언
- `mimetype`, `META-INF/`, `BinData/`, `Preview/` — **건드리지 않는다**

문단은 `<hp:p>`, 글자는 그 안의 `<hp:t>`.

## 2. ★ 가장 중요: linesegarray 를 지운다 ★

글자를 바꾼 `<hp:p>` 에서 반드시 `<hp:linesegarray>` 자식 요소를 삭제한다.
이것은 "몇 번째 글자가 화면 어디에 놓이는지" 적어 둔 **줄 배치 캐시**다.
글자 수가 달라졌는데 남아 있으면 **글자가 겹치거나 쪽이 넘어간다.**
지우면 한컴오피스가 파일을 열 때 다시 계산한다.

```python
from lxml import etree
import copy

tree = etree.parse('original/Contents/section0.xml')
root = tree.getroot()

def remove_linesegarray(p):
    for child in list(p):
        if etree.QName(child.tag).localname == 'linesegarray':
            p.remove(child)

def set_text(t_elem, new_text):
    t_elem.text = new_text
    remove_linesegarray(t_elem.getparent().getparent())   # run → p

# 마무리 안전장치
for elem in root.iter():
    if etree.QName(elem.tag).localname == 'p':
        remove_linesegarray(elem)
```

### 절대 금지

- XML을 문자열(f-string, `+`, `.replace()`, `re.sub()`)로 조합하지 않는다
- XML 선언을 손으로 붙이지 않는다
- `section0.xml` 을 통째로 새로 쓰지 않는다

## 3. 줄이 늘어날 때 — 문단 복제

```python
def insert_lines(parent, ref_p, texts):
    idx = list(parent).index(ref_p)
    for t in ref_p.iter():
        if etree.QName(t.tag).localname == 't':
            t.text = texts[0]; break
    remove_linesegarray(ref_p)
    for i, txt in enumerate(texts[1:], 1):
        new_p = copy.deepcopy(ref_p)
        for t in new_p.iter():
            if etree.QName(t.tag).localname == 't':
                t.text = txt; break
        remove_linesegarray(new_p)
        parent.insert(idx + i, new_p)
```

## 4. 회색 → 검은색

빈 양식의 안내 글씨는 `textColor="#808080"` charPr을 쓴다.
채운 문단은 header.xml에서 **같은 크기의 `textColor="#000000"` charPr id**를 찾아
`charPrIDRef` 를 그것으로 바꾼다.

## 5. 저장 · 재패키징

```python
tree.write('original/Contents/section0.xml', xml_declaration=True,
           encoding=tree.docinfo.encoding or 'UTF-8',
           standalone=tree.docinfo.standalone)

import zipfile, os
out = '가정통신문_결과.hwpx'
with zipfile.ZipFile(out, 'w') as zf:
    zf.write('original/mimetype', 'mimetype', compress_type=zipfile.ZIP_STORED)  # 반드시 첫 번째, 비압축
    for dirpath, _, filenames in os.walk('original'):
        for fn in filenames:
            fp = os.path.join(dirpath, fn)
            arc = os.path.relpath(fp, 'original')
            if arc == 'mimetype':
                continue
            zf.write(fp, arc, compress_type=zipfile.ZIP_DEFLATED)
```

## 6. 검증 — 저장 후 반드시

```python
with zipfile.ZipFile(out) as zf:
    assert zf.testzip() is None
    x = zf.read('Contents/section0.xml').decode('utf-8')
    assert 'linesegarray' not in x, "줄 배치 캐시가 남아 있음"
```

문단 수를 세어 **본문 상자 안의 줄이 30줄을 넘지 않는지** 확인한다.
넘으면 1쪽을 넘길 가능성이 높으니 내용을 줄여 다시 만든다.
